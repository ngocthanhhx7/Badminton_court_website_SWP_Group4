/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.AdminDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.User;
import model.Admin;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        HttpSession session = request.getSession();

        if ("admin".equals(role)) {
            Admin admin = new AdminDAO().checkLogin(email, password);
            if (admin != null) {
                session.setAttribute("admin", admin);
                response.sendRedirect("admin-dashboard.jsp");
                return;
            }
        } else {
            User user = new UserDAO().checkLogin(email, password);
            if (user != null) {
                session.setAttribute("user", user);
                session.setAttribute("currentUser", user);
                response.sendRedirect("welcome.jsp");
                return;
            }
        }

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<h2>Đăng nhập thất bại!</h2>");
        out.println("<a href='login.html'>Thử lại</a>");
    }
}
