/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.*;
import model.User;
import utils.DBConnection;

public class UserDAO {
    public User checkLogin(String email, String password) {
        String sql = "SELECT * FROM Users WHERE Email = ? AND Password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new User(
                    rs.getString("Username"),
                    password,
                    email,
                    rs.getString("FullName"),
                    rs.getString("Dob"),
                    rs.getString("Gender"),
                    rs.getString("Phone"),
                    rs.getString("Address"),
                    rs.getString("SportLevel"),
                    rs.getString("Role"),
                    rs.getString("CreatedBy")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

public void updateUser(User user) {
    String selectSql = "SELECT UpdatedAt FROM Users WHERE Email = ?";
    String updateSql = "UPDATE Users SET FullName = ?, Dob = ?, Gender = ?, Phone = ?, Address = ?, SportLevel = ?, CreatedAt = ?, UpdatedAt = ? WHERE Email = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement selectPs = conn.prepareStatement(selectSql);
         PreparedStatement updatePs = conn.prepareStatement(updateSql)) {

        // 1. Lấy UpdatedAt hiện tại từ DB (dùng làm CreatedAt mới)
        Timestamp prevUpdatedAt = null;
        selectPs.setString(1, user.getEmail());
        try (ResultSet rs = selectPs.executeQuery()) {
            if (rs.next()) {
                prevUpdatedAt = rs.getTimestamp("UpdatedAt");
            }
        }

        // 2. Nếu không có user thì thoát
        if (prevUpdatedAt == null) {
            System.out.println("User không tồn tại.");
            return;
        }

        // 3. Thời gian mới
        Timestamp now = new Timestamp(System.currentTimeMillis());

        // 4. Update thông tin + thời gian
        updatePs.setString(1, user.getFullName());
        updatePs.setString(2, user.getDob());
        updatePs.setString(3, user.getGender());
        updatePs.setString(4, user.getPhone());
        updatePs.setString(5, user.getAddress());
        updatePs.setString(6, user.getSportLevel());
        updatePs.setTimestamp(7, prevUpdatedAt); // CreatedAt = UpdatedAt cũ
        updatePs.setTimestamp(8, now);           // UpdatedAt = hiện tại
        updatePs.setString(9, user.getEmail());

        updatePs.executeUpdate();

        System.out.println("Cập nhật thành công. CreatedAt: " + prevUpdatedAt + ", UpdatedAt: " + now);
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
}