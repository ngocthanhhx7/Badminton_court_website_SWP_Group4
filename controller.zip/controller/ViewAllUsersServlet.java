package controller;

import dao.UserDAO;


import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.List;
import models.User;

@WebServlet("/view-all-users")
public class ViewAllUsersServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<User> users = new UserDAO().getAllUsers();
        request.setAttribute("users", users);
        request.getRequestDispatcher("view-users.jsp").forward(request, response);
    }
}
