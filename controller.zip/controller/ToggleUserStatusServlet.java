package controller;

import dao.UserDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet("/toggle-status")
public class ToggleUserStatusServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String action = request.getParameter("action");

        if (email != null && action != null) {
            UserDAO dao = new UserDAO();

            if ("deactivate".equals(action)) {
                dao.updateStatus(email, "Inactive");
            } else if ("activate".equals(action)) {
                dao.updateStatus(email, "Active");
            }
        }

        response.sendRedirect("view-all-users");
    }
}
