package controller;

import dao.UserDAO;


import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import models.User;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
    private final UserDAO dao = new UserDAO();

    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        try {
            switch (action) {
                case "editform":
                    int id = Integer.parseInt(req.getParameter("id"));
                    User u = dao.getUserById(id);
                    req.setAttribute("user", u);
                    req.getRequestDispatcher("edit-user.jsp").forward(req, resp);
                    break;
                case "list":
                    List<User> users = dao.getAllUsers();
                    req.setAttribute("userList", users);
                    req.getRequestDispatcher("view-users.jsp").forward(req, resp);
                    break;
                case "delete":
                    int delId = Integer.parseInt(req.getParameter("id"));
                    dao.deleteUser(delId);
                    resp.sendRedirect("UserController?action=list");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("edit".equals(action)) {
            try {
                User u = new User();
                u.setId(Integer.parseInt(req.getParameter("id")));
                u.setUsername(req.getParameter("username"));
                u.setPassword(req.getParameter("password"));
                u.setEmail(req.getParameter("email"));
                u.setFullName(req.getParameter("fullName"));
                u.setBirthDate(LocalDate.parse(req.getParameter("dob")));
                u.setGender(req.getParameter("gender"));
                u.setPhone(req.getParameter("phone"));
                u.setAddress(req.getParameter("address"));
                u.setSportLevel(req.getParameter("sportLevel"));
                u.setRole(req.getParameter("role"));
                u.setStatus(req.getParameter("status"));
                u.setCreatedBy(req.getParameter("createdBy"));
                u.setUpdatedAt(LocalDateTime.now());
                u.setActive(true);
                dao.updateUser(u);
                resp.sendRedirect("UserController?action=list");
            } catch (Exception e) {
                e.printStackTrace();
                req.setAttribute("error", "Cập nhật thất bại.");
                req.getRequestDispatcher("edit-user.jsp").forward(req, resp);
            }
        }
    }
}