/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import dao.BookingDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class AdminRevenueServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String type = request.getParameter("type"); // "week" hoặc "month"
        int time = Integer.parseInt(request.getParameter("time")); // tuần hoặc tháng
        int year = Integer.parseInt(request.getParameter("year")); // năm

        BookingDAO dao = new BookingDAO();
        double total = 0;
        try {
            if ("week".equals(type)) {
                total = dao.getWeeklyRevenue(time, year);
            } else if ("month".equals(type)) {
                total = dao.getMonthlyRevenue(time, year);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("total", total);
        request.setAttribute("type", type);
        request.setAttribute("time", time);
        request.setAttribute("year", year);
        request.getRequestDispatcher("view-revenue.jsp").forward(request, response);
    }
}

